/**
 * Created by hp 1 on 3/29/2017.
 */
public class CitiesData {
    // variables for reading from the file
    public int LocationId;
    public String Country;
    public String Region;
    public String City;
    public int PostalCode;
    public float Latitude;
    public float Longitude;
    public int MetroCode;
    public int AreaCode;

}
