/**
 * Created by hp 1 on 3/29/2017.
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.IOException;

public class CitySearch {


    public static void main(String[] args) throws FileNotFoundException {
        System.out.println("");
        System.out.println("MY CITY SEARCH APPLICATION");
        System.out.println("");
        // reading from the CSV FILE
        Scanner scanner = new Scanner(new File("C:/Users/hp 1/Downloads/GeoLiteCity-Location.csv"));
        scanner.useDelimiter(",");
        while(scanner.hasNext()){
            System.out.print(scanner.next()+"|");
        }
        scanner.close();

}
}
