import junit.framework.TestCase;

/**
 * Created by hp 1 on 3/2/2017.
 */
public class reservationTest extends TestCase {
    public void testIs_available() throws Exception {
        available_tables at[]=new available_tables[4];
        at[0]=new available_tables(); //for 11-13 // initially have all the tables in it as they all are initially available
        at[1]=new available_tables();//for 13-15// initially have all the tables in it as they all are initially available
        at[2]=new available_tables(); //for 15-17 // initially have all the tables in it as they all are initially available
        at[3]=new available_tables();//for 17-20// initially have all the tables in it as they all are initially available
        reservation R1=new reservation(1,"Menobia",14,12);
        reservation R2=new reservation(2,"Hassan",7,12);
        assertTrue(R1.is_available(at));

    }

}