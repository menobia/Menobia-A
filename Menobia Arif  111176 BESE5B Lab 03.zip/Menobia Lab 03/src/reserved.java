/**
 * Created by hp 1 on 3/2/2017.
 */
public class reserved { //linked list to store the reservations

    private reservation head;
    private reservation current;

    public reserved() {
        head = null;
        current = null;
}

    public boolean reserve(reservation R, available_tables t[])
            // if table is available at that time it adds the reservation to the reserved list
    {
        if (R.is_available(t) == true) {
            reservation newR = R;
            if (head == null)
                head = R;
            else {
                current = head;
                while (current.next != null)
                    current = current.next;
                current.next = R;
            }
            if (R.Time >= 11 && R.Time <= 12) {
                t[0].remove(R.People);
            }
            if (R.Time >= 13 && R.Time <= 14) {
                t[1].remove(R.People);
            }
            if (R.Time >= 15 && R.Time <= 16) {
                t[2].remove(R.People);
            }
            if (R.Time >= 17 && R.Time <= 18) {
                t[3].remove(R.People);
            }
            System.out.println("RESERVATION SUCCESSFUL");
            return true;
        }

        else
        {System.out.println("RESERVATION UNSUCCESSFUL (Unavailable)");
            return false;
        }

    }


    public void remove(int ID,available_tables t[] )// removes the reservation on cencellation
    {reservation temp,previous;
        previous=head;
        temp=head;
        while ((temp != null) && (temp.ID!= ID))
        {
            previous = temp;
            temp = temp.next;
        }
        if (temp.Time >= 11 && temp.Time <= 12) {
            t[0].add("type",temp.People);
        }
        if (temp.Time >= 13 && temp.Time <= 14) {
            t[1].add("type",temp.People);
        }
        if (temp.Time >= 15 && temp.Time <= 16) {
            t[2].add("type",temp.People);
        }
        if (temp.Time >= 17 && temp.Time <= 19) {
            t[3].add("type",temp.People);
        }
        if (temp == head)//if user wants to delete the first node
        {
            head = temp.next;
            temp = null;
        }
        else if (temp.next==null)         //if want to delete node at end
        {
            previous.next=null;
            current = previous;
            temp = null;
        }
        else if (temp.next != null) //if want to delete node in-between the list
        {
            previous.next= temp.next;
            temp = null;
        }


    }

    public boolean searchReservation(int ID){
        reservation temp;
        temp=head;
        while ((temp != null) && (temp.ID!=ID))
        {
            temp = temp.next;
        }
        if (temp!=null)
            return true;
        else return false;
    }
    public void display() // function to display the list
    {
        current = head;
        if (head==null){ // if no nodes
            System.out.println("EMPTY");
        }
        System.out.println(" ");
        System.out.println("RESRAVATIONS");
        System.out.println("---------");
        System.out.println("  -----");
        System.out.println("    -");

        while (current!=null)
        {

            System.out.println("Reservation ID: "+ current.ID);
            System.out.println("Reserved By: " + current.reservedby);
            System.out.println(current.People + " People");
            System.out.println("Reservation Time: " + current.Time);
            current=current.next;  System.out.println(" ");
        }

    }
}
