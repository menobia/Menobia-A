/**
 * Created by hp 1 on 3/1/2017.
 */
import java.util.Scanner;


public class rest_reserv {
    public static void main(String args[]) {

available_tables AT[]=new available_tables[4];
            AT[0]=new available_tables(); //for 11-13 // initially have all the tables in it as they all are initially available
            AT[1]=new available_tables();//for 13-15// initially have all the tables in it as they all are initially available
        AT[2]=new available_tables(); //for 15-17 // initially have all the tables in it as they all are initially available
        AT[3]=new available_tables();//for 17-20// initially have all the tables in it as they all are initially available

            reserved Res=new reserved(); // list for reservations //initially empty as no reservation in the begining
reservation R1= new reservation(1,"Menobia Arif",13,12);
reservation R2= new reservation(2,"Sanea Abid",15,12);
reservation R3= new reservation(3,"Ayesha khan",19,2);
reservation R4= new reservation(4,"Maham safdar",15,6);
reservation R5= new reservation(5,"Kubra Fatima",11,8);
reservation R6= new reservation(2,"Sanea Abid",15,12);

        Res.reserve(R1,AT);
        Res.reserve(R2,AT);
        Res.reserve(R3,AT);
        Res.reserve(R4,AT);
        Res.reserve(R5,AT);
        Res.reserve(R6,AT);

        Res.display();
}}
