/**
 * Created by hp 1 on 3/1/2017.
 */
public class Table {
    public String type;  // small, medium, large. extralarge
    public int seats;// number of seats in that table
    public  Table next; // for the linked list

    public Table(String T,int S) {
        this.type = T;
        this.seats=S;
        next=null;
    }

    public void printTable() {
        System.out.println("Type:"+ type );
        System.out.println("Seats:" + seats );

    }

}
