import org.hibernate.HibernateException;
import org.hibernate.Metamodel;
import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.metamodel.EntityType;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.IOException;
/**
 * Created by nashm on 29/03/2017.
 */
public class Main{
    private static final SessionFactory ourSessionFactory;

    static {
        try {
            Configuration configuration = new Configuration();
            configuration.configure();

            ourSessionFactory = configuration.buildSessionFactory();
        } catch (Throwable ex) {
            throw new ExceptionInInitializerError(ex);
        }
    }

    public static Session getSession() throws HibernateException {
        return ourSessionFactory.openSession();
    }

    public static void main(final String[] args) throws Exception {
        final Session session = getSession();

        String csvFile = "src/test_two-anon.csv";
        T ml = new T();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String[] Line;
        String[] temp;
        try {
            br = new BufferedReader(new FileReader(csvFile));
            int lineNo = 0;
            while ((line = br.readLine()) != null){
                lineNo++;

                if(lineNo >3){
                    temp = line.split(",");
                    System.out.println(line);
                        String id = temp[0].replace("\"", "");
                        String sc = temp[2].replace("\"", "");
                        float tt = Float.parseFloat(temp[3]);
                        String s = temp[4].replace("\"", "");
                        float t1 = Float.parseFloat(temp[6]);
                        String s1 = temp[7].replace("\"", "");
                        float t2 = Float.parseFloat(temp[9]);
                        String s2 = temp[10].replace("\"", "");
                        float t3 = Float.parseFloat(temp[12]);
                        String s3 = temp[13].replace("\"", "");
                        float t4 = Float.parseFloat(temp[15]);
                        String s4 = temp[16].replace("\"", "");
                        float t5 = Float.parseFloat(temp[18]);
                        String s5 = temp[19].replace("\"", "");
                        float t6 = Float.parseFloat(temp[21]);
                        String s6 = temp[22].replace("\"", "");

                        ml.addEntry(id,sc, tt, s,t1,s1,t2,s2,t3,s3, t4, s4,t5,s5,t6,s6);
                    }





                }


            System.out.println("querying all the managed entities...");
            final Metamodel metamodel = session.getSessionFactory().getMetamodel();
            for (EntityType<?> entityType : metamodel.getEntities()) {
                final String entityName = entityType.getName();
                final Query query = session.createQuery("from " + entityName);
                System.out.println("executing: " + query.getQueryString());
                for (Object o : query.list()) {
                    System.out.println("  " + o);
                }
            }
        } finally {
            session.close();
        }
    }

}