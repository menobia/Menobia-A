import org.hibernate.*;
import org.hibernate.cfg.Configuration;

/**
 * Created by nashm on 29/03/2017.
 */
public class T {
    private static SessionFactory factory;

    T(){
        try{
            factory = new Configuration().configure().buildSessionFactory();
        }catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public int addEntry(String id, String sc, float tt, String s,float t1,String s1,float t2,String s2,float t3,String s3,float t4,String s4,float t5,String s5,float t6,String s6){
        Session session = factory.openSession();
        Transaction tx = null;
        int id1=0;
        try{
            tx = session.beginTransaction();
            TestT al = new TestT(id,sc, tt, s,t1,s1,t2,s2,t3,s3, t4, s4,t5,s5,t6,s6);
            id1 = (Integer) session.save(al);
            tx.commit();
        }
        catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }
        finally{
            session.close();
        }
        return id1;
    }

}
