/**
 * Created by menobia on 29/03/2017.
 */

// persistance class

public class TestT {
    private String id;
    private String scheme;
    private float timetaken;
    private String state;
    private float t1;
    private String s1;
    private float t2;
    private String s2;
    private float t3;
    private String s3;
    private float t4;
    private String s4;
    private float t5;
    private String s5;
    private float t6;
    private String s6;
    public TestT(){}

    public TestT(String id, String sc, float tt, String s,float t1,String s1,float t2,String s2,float t3,String s3,float t4,String s4,float t5,String s5,float t6,String s6){
        this.id = id;
        this.scheme = sc;
        this.timetaken = tt;
        this.state = s;
        this.t1=t1;
        this.s1=s1;
        this.t2=t2;
        this.s2=s2;
        this.t3=t3;
        this.s3=s3;
        this.t4=t4;
        this.s4=s4;
        this.t5=t5;
        this.s5=s5;
        this.t6=t6;
        this.s6=s6;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getScheme() {
        return scheme;
    }

    public void setScheme(String scheme) {
        this.scheme = scheme;
    }

    public float getTimetaken() {
        return timetaken;
    }

    public void setTimetaken(float timetaken) {
        this.timetaken = timetaken;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public float getT1() {
        return t1;
    }

    public void setT1(float t1) {
        this.t1 = t1;
    }

    public String getS1() {
        return s1;
    }

    public void setS1(String s1) {
        this.s1 = s1;
    }

    public float getT2() {
        return t2;
    }

    public void setT2(float t2) {
        this.t2 = t2;
    }

    public String getS2() {
        return s2;
    }

    public void setS2(String s2) {
        this.s2 = s2;
    }

    public float getT3() {
        return t3;
    }

    public void setT3(float t3) {
        this.t3 = t3;
    }

    public String getS3() {
        return s3;
    }

    public void setS3(String s3) {
        this.s3 = s3;
    }

    public float getT4() {
        return t4;
    }

    public void setT4(float t4) {
        this.t4 = t4;
    }

    public String getS4() {
        return s4;
    }

    public void setS4(String s4) {
        this.s4 = s4;
    }

    public float getT5() {
        return t5;
    }

    public void setT5(float t5) {
        this.t5 = t5;
    }

    public String getS5() {
        return s5;
    }

    public void setS5(String s5) {
        this.s5 = s5;
    }

    public float getT6() {
        return t6;
    }

    public void setT6(float t6) {
        this.t6 = t6;
    }

    public String getS6() {
        return s6;
    }

    public void setS6(String s6) {
        this.s6 = s6;
    }
}
