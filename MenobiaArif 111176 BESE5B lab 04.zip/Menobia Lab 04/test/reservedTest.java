import junit.framework.TestCase;

/**
 * Created by hp 1 on 3/2/2017.
 */
public class reservedTest extends TestCase {
    public void testReserve() throws Exception {
        available_tables AT[]=new available_tables[4];
        AT[0]=new available_tables(); //for 11-13 // initially have all the tables in it as they all are initially available
        AT[1]=new available_tables();//for 13-15// initially have all the tables in it as they all are initially available
        AT[2]=new available_tables(); //for 15-17 // initially have all the tables in it as they all are initially available
        AT[3]=new available_tables();//for 17-20// initially have all the tables in it as they all are initially available
        reserved Res=new reserved(); // list for reservations //initially empty as no reservation in the begining
        reservation R1=new reservation(1,"Menobia",13,12);
        reservation R2=new reservation(2,"Hassan",13,12);  // same reservation so second one will be false
        assertTrue( Res.reserve(R1,AT));
        assertFalse( Res.reserve(R1,AT));
        Res.remove(1,AT); // removing reservation R1


        assertTrue(Res.reserve(R2,AT)); // trying for R2 after removing R1
        Res.remove(2,AT); // removing reservation R2
        reservation R5=new reservation(5,"Hamid",17,12); // same table  at different timings should be true
        reservation R6=new reservation(6,"ALi",13,12);
        assertTrue( Res.reserve(R5,AT));
        assertTrue(Res.reserve(R6,AT));

        reservation R3=new reservation(3,"Sanea",13,4);
        reservation R4=new reservation(4,"Ayesha",14,2); // same timings different tables should be true
        assertTrue( Res.reserve(R3,AT));
        assertTrue(Res.reserve(R4,AT));
}

}