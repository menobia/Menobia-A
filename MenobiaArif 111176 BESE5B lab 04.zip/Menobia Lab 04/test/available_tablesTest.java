import junit.framework.TestCase;

/**
 * Created by hp 1 on 3/2/2017.
 */
public class available_tablesTest extends TestCase {
    public void testSearchtable() throws Exception {
        available_tables at =new available_tables();
        assertFalse(at.searchtable(14)); // no table with 13 seats
        assertTrue(at.searchtable(12)); // yes a table is available for 12 seats
        at.remove(12);
        assertFalse(at.searchtable(12)); // as there was only one 12 seats table
    }

}