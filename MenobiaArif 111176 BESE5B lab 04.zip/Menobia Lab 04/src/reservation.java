/**
 * Created by hp 1 on 3/2/2017.
 */

public class reservation  // stores the reservation to be made
{
    public int ID;
    public String reservedby;
    public int Time; //time in 24 hour clock
    public int People;
    public reservation next;
    public Table T;
    public reservation(int I,String R,int t, int P){
        ID=I;
        reservedby=R;
        Time=t;
        People=P;
        T=null;
        next=null;
    }

    public boolean is_available(available_tables tabless[]) // checks if a table is available for reservation or not
    {


        if (Time >= 11 && Time <= 12) {
            if (tabless[0].searchtable(People) == true)
                return true;
            else
                return false;
        }
        if (Time >= 13 && Time <= 14) {
            if (tabless[1].searchtable(People) == true)
                return true;
            else
                return false;
        }
        if (Time >= 15 && Time <= 16) {
            if (tabless[2].searchtable(People) == true)
                return true;
            else
                return false;
        }
        if (Time >= 17 && Time <= 19) {
            if (tabless[3].searchtable(People) == true)
                return true;
            else
                return false;
        }
        else
            return false;
    }
}


