import java.sql.*;

public class Db{
    public static void main(String[] args) {
        String DB_URL = "jdbc:mysql://localhost/";
        String DB_USER = "root";
        String DB_PASS = "";

        Connection conn = null;
        Statement stmt = null;

        try{
            Class.forName("com.mysql.jdbc.Driver");

            conn = DriverManager.getConnection(DB_URL,DB_USER,DB_PASS);
            stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM Resturant.reservation ");
            while(rs.next()) {
                System.out.println("Reservation_Id : " + rs.getInt("IdReservation"));
                System.out.println("Reserved By : " + rs.getString("RservedBy"));
                System.out.println("People : " + rs.getInt("People"));
                System.out.println("Time : " + rs.getInt("Time"));
            }
        } catch(Exception e){
            e.printStackTrace();
        } finally {

        }
    }
}