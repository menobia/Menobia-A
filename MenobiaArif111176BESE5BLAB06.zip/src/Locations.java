import org.hibernate.*;
import org.hibernate.cfg.Configuration;

/**
 * Created by nashm on 29/03/2017.
 */
public class Locations {
    private static SessionFactory factory;

   Locations(){
        try{
            factory = new Configuration().configure().buildSessionFactory();
        }catch (Throwable ex) {
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex);
        }
    }

    public int addEntry7(int id, String co, String re, String ci, String pc, float lat, float lon){
        Session session = factory.openSession();
        Transaction tx = null;
        int id1=0;
        try{
            tx = session.beginTransaction();
            CityData al = new CityData(id, co, re, ci, pc, lat, lon);
            id1 = (Integer) session.save(al);
            tx.commit();
        }
        catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }
        finally{
            session.close();
        }
        return id1;
    }

    public int addEntry9(int id, String co, String re, String ci, String pc, float lat, float lon, int mc, int ac){
        Session session = factory.openSession();
        Transaction tx = null;
        int id1=0;
        try{
            tx = session.beginTransaction();
            CityData al = new  CityData(id, co, re, ci, pc, lat, lon, mc, ac);
            id1 = (Integer) session.save(al);
            tx.commit();
        }
        catch(HibernateException e){
            if(tx!=null) tx.rollback();
            e.printStackTrace();
        }
        finally{
            session.close();
        }
        return id1;
    }


}
